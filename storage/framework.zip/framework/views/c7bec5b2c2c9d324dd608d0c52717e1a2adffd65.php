	<script type="text/javascript" src="<?php echo e(asset('files/js/jquery-1.11.1.min.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('files/js/bootstrap.min.js')); ?>"></script>
	<!-- SLIDER REVOLUTION 4.x SCRIPTS  -->
    <script src="<?php echo e(asset('files/rs-plugin/js/jquery.themepunch.tools.min.js')); ?>"></script>
    <script src="<?php echo e(asset('files/rs-plugin/js/jquery.themepunch.revolution.min.js')); ?>"></script>

	<script type="text/javascript" src="<?php echo e(asset('files/js/plugins.js')); ?>"></script>
	<script type="text/javascript" src="<?php echo e(asset('files/js/custom.js')); ?>"></script>

</body>
</html><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/scripts.blade.php ENDPATH**/ ?>