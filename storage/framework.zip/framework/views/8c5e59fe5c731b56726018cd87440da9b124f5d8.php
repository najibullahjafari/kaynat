<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>Add New Staff</h1>
    </section>
    <section class="content">
        <div class="card" style="max-width:500px;margin:auto;">
            <div class="card-body">
                <form method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-3">
                        <label for="name">Name</label>
                        <input class="form-control" type="text" id="name" name="name" placeholder="Name" required>
                    </div>
                    <div class="form-group mb-3">
                        <label for="type">Type</label>
                        <select class="form-control" id="type" name="type" required>
                            <option value="">Select Type</option>
                            <option value="employee">Employee</option>
                            <option value="head">Head</option>
                        </select>
                    </div>
                    <div class="form-group mb-3">
                        <label for="bio">Bio</label>
                        <textarea class="form-control" id="bio" name="bio" placeholder="Bio"></textarea>
                    </div>
                    <div class="form-group mb-3">
                        <label for="image">Image</label>
                        <input class="form-control" type="file" id="image" name="image" required>
                    </div>
                    <button type="submit" name="submit_staff" class="btn btn-primary w-100">Add Staff</button>
                </form>
            </div>
        </div>
    </section>
</div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/admin/add-staff.blade.php ENDPATH**/ ?>