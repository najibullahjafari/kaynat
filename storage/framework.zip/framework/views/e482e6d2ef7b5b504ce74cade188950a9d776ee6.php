<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="content-wrapper">
    <section class="content-header">
        <h1>All Staff</h1>
    </section>
    <section class="content">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered table-striped">
                    <thead class="thead-dark">
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Bio</th>
                            <th>Image</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($staff->name); ?></td>
                            <td><?php echo e($staff->type); ?></td>
                            <td><?php echo e($staff->bio); ?></td>
                            <td>
                                <?php if($staff->image): ?>
                                <img src="<?php echo e(asset('staff_images/'.$staff->image)); ?>" width="50" class="img-thumbnail">
                                <?php else: ?>
                                <span class="text-muted">No Image</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="/admin/edit-staff/<?php echo e($staff->id); ?>" class="btn btn-sm btn-primary">Edit</a>
                                <form action="/admin/delete-staff/<?php echo e($staff->id); ?>" method="POST"
                                    style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-sm btn-danger"
                                        onclick="return confirm('Delete?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>
</div>
<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/admin/view-staff.blade.php ENDPATH**/ ?>