<footer class="main-footer">
  <strong>Copyright &copy; 2025 <a href="https://wce.af">Wind Cloud</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
  </div>
</footer><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/admin/footer.blade.php ENDPATH**/ ?>