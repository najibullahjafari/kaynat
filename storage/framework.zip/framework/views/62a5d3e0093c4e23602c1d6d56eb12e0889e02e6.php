<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>All Jobs</h1>
                </div>
            </div>
        </div>
    </section>

    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Job List</h3>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Company</th>
                                        <th>Location</th>
                                        <th>Employment Type</th>
                                        <th>Industry</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($job->title); ?></td>
                                        <td><?php echo e($job->company); ?></td>
                                        <td><?php echo e($job->location); ?></td>
                                        <td>
                                            
                                            <a href="<?php echo e(url('/admin/job/' . $job->id . '/applicants')); ?>"
                                                class="btn btn-info btn-sm">
                                                View (<?php echo e($job->applicants_count); ?>)
                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('/admin/edit-job/' . $job->id)); ?>"
                                                class="btn btn-warning btn-sm">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                            <form action="<?php echo e(url('/admin/delete-job/' . $job->id)); ?>" method="POST"
                                                style="display:inline;"
                                                onsubmit="return confirm('Are you sure you want to delete this job?');">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fa fa-trash"></i> Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('admin/scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/admin/view-jobs.blade.php ENDPATH**/ ?>