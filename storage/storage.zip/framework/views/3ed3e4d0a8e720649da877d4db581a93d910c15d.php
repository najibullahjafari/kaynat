<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="slider">
	<div class="fullwidthbanner-container">
		<div class="fullwidthbanner">
			<ul>
				<?php $__currentLoopData = $slider_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li class="first-slide" data-transition="fade" data-slotamount="10" data-masterspeed="300">
					<img src="<?php echo e(asset('images/'.$slider->image)); ?>" data-fullwidthcentering="on" alt="slide">
					<div class="tp-caption first-line lft tp-resizeme start" data-x="center" data-hoffset="0"
						data-y="250" data-speed="1000" data-start="200" data-easing="Power4.easeOut" data-splitin="none"
						data-splitout="none" data-elementdelay="0" data-endelementdelay="0"><?php echo e($slider->title); ?></div>
					<div class="tp-caption second-line lfb tp-resizeme start" data-x="center" data-hoffset="0"
						data-y="340" data-speed="1000" data-start="800" data-easing="Power4.easeOut" data-splitin="none"
						data-splitout="none" data-elementdelay="0" data-endelementdelay="0"><?php echo e($slider->details); ?></div>
					<div class="tp-caption slider-btn sfb tp-resizeme start" data-x="center" data-hoffset="0"
						data-y="510" data-speed="1000" data-start="2200" data-easing="Power4.easeOut"
						data-splitin="none" data-splitout="none" data-elementdelay="0" data-endelementdelay="0"><a
							href="#" class="btn btn-slider">Discover More</a></div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	</div>
</div>

<section class="services green services_edit">
	<div class="container">
		<div class="section-heading">
			<h2>What We Offer</h2>
			<div class="section-dec"></div>
		</div>

		<?php $i=0; ?>
		<?php $__currentLoopData = $services_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="service-item col-md-4">
			<span><i class="fa fa-support"></i></span>
			<div class="tittle">
				<h3><?php echo e($services->title); ?></h3>
			</div>
			<p><?php echo e($services->details); ?></p>
		</div>
		<?php $i++;
							if($i==3){break;}?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>

	<div class="container">
		<div class="view_more_service">
			<a href="/services" title="View All Services"><span>VIEW MORE SERVICES</span></a>
		</div>
	</div>
</section>

<section class="our-staff">
	<div class="container">
		<div class="section-heading">
			<h2>Our Staff</h2>
			<div class="section-dec"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="owl-staff" class="owl-carousel owl-theme">
					<?php $__currentLoopData = $staff_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<div class="staff-member">
							<?php if($staff->image): ?>
							<img src="<?php echo e(asset('staff_images/'.$staff->image)); ?>" alt="<?php echo e($staff->name); ?>">
							<?php endif; ?>
							<h4><?php echo e($staff->name); ?></h4>
							<span><?php echo e($staff->type); ?></span>
							<p><?php echo e($staff->bio); ?></p>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>



<section class="portfolio">
	<div class="container">
		<div class="section-heading-white">
			<h2>Recent Photos</h2>
			<div class="section-dec"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="owl-portfolio" class="owl-carousel owl-theme">

					<?php $__currentLoopData = $photos_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<figure>
							<img alt="portfolio" src="<?php echo e(asset('images/'.$photos->image)); ?>">
							<figcaption>
								<h3><?php echo e($photos->title); ?></h3>
								<p><?php echo e($photos->details); ?></p>
							</figcaption>
						</figure>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		</div>
		<div class="owl-navigation">
			<a class="btn prev fa fa-angle-left"></a>
			<a class="btn next fa fa-angle-right"></a>
			<a href="/work-3columns" class="go-to">Go to portfolio</a>
		</div>
	</div>
</section>

<section class="testimonials">
	<div class="container">
		<div class="section-heading">
			<h2 style="color:white;">What Others saying</h2>
			<div class="section-dec"></div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div id="owl-demo" class="owl-carousel owl-theme">

					<?php $__currentLoopData = $about_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $about): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="item">
						<div class="testimonials-post">
							<span class="fa fa-quote-left"></span>
							<p><?php echo e($about->thought); ?></p>
							<h6><?php echo e($about->name); ?> <em> <?php echo e($about->city); ?></em></h6>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</div>
			</div>
		</div>
	</div>
</section>


<section class="jobs-listing" style="padding: 60px 0;">
	<div class="container">
		<div class="section-heading">
			<h2>Available Jobs</h2>
			<div class="section-dec"></div>
		</div>
		<div class="row">
			<?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-md-6 col-lg-4">
				<div class="job-card" data-toggle="modal" data-target="#jobDetailModal" data-id="<?php echo e($job->id); ?>">
					<h4><?php echo e($job->title); ?></h4>
					<p><i class="fa fa-building-o"></i> <?php echo e($job->company); ?></p>
					<p><i class="fa fa-map-marker"></i> <?php echo e($job->location); ?></p>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="col-md-12 text-center">
				<p>No jobs available at the moment. Please check back later.</p>
			</div>
			<?php endif; ?>
		</div>
		<div class="view_more_service" style="margin-top: 30px;">
			<a href="/jobs" title="View All Jobs"><span>VIEW ALL JOBS</span></a>
		</div>
	</div>
</section>

<!-- (MODAL 1) Enhanced Job Detail Modal -->
<div class="modal fade" id="jobDetailModal" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header" style="background-color: #f7f7f7; border-bottom: 2px solid #337ab7;">
				<h4 class="modal-title" id="jobDetailTitle"></h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div id="modal-loader" style="text-align: center;"><i class="fa fa-spinner fa-spin fa-3x"></i></div>
				<div id="modal-content-area" style="display:none;">
					<h5 id="jobDetailCompany" style="font-weight: bold;"></h5>
					<p><i class="fa fa-map-marker"></i> <span id="jobDetailLocation"></span> &nbsp;&nbsp; | &nbsp;&nbsp;
						<i class="fa fa-briefcase"></i> <span id="jobDetailType"></span>
					</p>
					<hr>
					<!-- Nav tabs -->
					<ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active"><a href="#summary" aria-controls="summary" role="tab"
								data-toggle="tab">Summary</a></li>
						<li role="presentation"><a href="#duties" aria-controls="duties" role="tab"
								data-toggle="tab">Duties</a></li>
						<li role="presentation"><a href="#qualifications" aria-controls="qualifications" role="tab"
								data-toggle="tab">Qualifications</a></li>
					</ul>
					<!-- Tab panes -->
					<div class="tab-content" style="padding: 20px 0;">
						<div role="tabpanel" class="tab-pane active" id="summary">
							<h6>About the Company</h6>
							<p id="jobDetailAboutCompany"></p>
							<h6>Job Summary</h6>
							<p id="jobDetailSummary"></p>
						</div>
						<div role="tabpanel" class="tab-pane" id="duties">
							<h6>Duties & Responsibilities</h6>
							<p id="jobDetailDuties"></p>
						</div>
						<div role="tabpanel" class="tab-pane" id="qualifications">
							<h6>Education & Qualifications</h6>
							<p id="jobDetailEducation"></p>
							<h6>Experience & Skills</h6>
							<p id="jobDetailExperience"></p>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary apply-btn">Apply Now</button>
			</div>
		</div>
	</div>
</div>

<style>
	.job-card {
		background-color: #fff;
		border: 1px solid #eee;
		border-radius: 5px;
		padding: 20px;
		margin-bottom: 30px;
		cursor: pointer;
		transition: all 0.3s ease-in-out;
		box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
	}

	.job-card:hover {
		transform: translateY(-5px);
		box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
	}
</style>


<section class="blog-posts">
	<div class="container">
		<div class="section-heading">
			<h2>Latest Posts</h2>
			<div class="section-dec"></div>
		</div>

		<?php $__currentLoopData = $blog_i; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="blog-item">
			<div class="col-md-4">
				<a href="/blog-single/<?php echo e($blog->id); ?>"><img src="<?php echo e(asset('images/'.$blog->image)); ?>" alt=""></a>
				<h3><a href="/blog-single/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a></h3>

				<p><?php echo e($blog->short_details); ?></p>
				<div class="read-more">
					<a href="/blog-single/<?php echo e($blog->id); ?>">Read more</a>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	</div>
</section>

<!-- (MODAL 1) Enhanced Job Detail Modal -->
<div style="margin-top:100px; " class="modal fade mt-4" id="jobDetailModal" tabindex="-1" role="dialog">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header" style="background-color: #f7f7f7; border-bottom: 2px solid #337ab7;">
				<h4 class="modal-title" id="jobDetailTitle"></h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
			</div>
			<div class="modal-body">
				<div id="modal-loader" style="text-align: center; padding: 40px;"><i
						class="fa fa-spinner fa-spin fa-3x"></i></div>
				<div id="modal-content-area" style="display:none;">
					<h5 id="jobDetailCompany" style="font-weight: bold;"></h5>
					<p><i class="fa fa-map-marker"></i> <span id="jobDetailLocation"></span> &nbsp;&nbsp; |
						&nbsp;&nbsp;
						<i class="fa fa-briefcase"></i> <span id="jobDetailType"></span>
					</p>
					<hr>
					<ul class="nav nav-tabs" role="tablist">
						<li role="presentation" class="active"><a href="#summary" aria-controls="summary" role="tab"
								data-toggle="tab">Summary</a></li>
						<li role="presentation"><a href="#duties" aria-controls="duties" role="tab"
								data-toggle="tab">Duties</a></li>
						<li role="presentation"><a href="#qualifications" aria-controls="qualifications" role="tab"
								data-toggle="tab">Qualifications</a></li>
					</ul>
					<div class="tab-content" style="padding: 20px 0;">
						<div role="tabpanel" class="tab-pane active" id="summary">
							<h6>About the Company</h6>
							<p id="jobDetailAboutCompany"></p>
							<h6>Job Summary</h6>
							<p id="jobDetailSummary"></p>
						</div>
						<div role="tabpanel" class="tab-pane" id="duties">
							<h6>Duties & Responsibilities</h6>
							<p id="jobDetailDuties"></p>
						</div>
						<div role="tabpanel" class="tab-pane" id="qualifications">
							<h6>Education & Qualifications</h6>
							<p id="jobDetailEducation"></p>
							<h6>Experience & Skills</h6>
							<p id="jobDetailExperience"></p>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary wind-btn ">Apply Now</button>
			</div>
		</div>
	</div>
</div>
<!-- (MODAL 2) Application Form Modal -->
<div style="margin-top:50px; " class="modal fade mt-8" id="applyModal" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">

		<div class="modal-content">
			<div class="flex justify-between align-items-center modal-header">
				<h4 class="modal-title">Apply for: <span id="applyJobTitle"></span></h4>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
						aria-hidden="true">&times;</span></button>
			</div>
			<form action="<?php echo e(url('/apply-for-job')); ?>" method="POST" enctype="multipart/form-data"
				style="padding: 20px;">
				<?php echo csrf_field(); ?>
				<input type="hidden" name="job_id" id="applyJobId">

				<div class="modal-body">
					<div class="form-group">
						<label>Full Name</label>
						<input type="text" name="full_name" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Email</label>
						<input type="email" name="email" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Contact Number</label>
						<input type="text" name="contact" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Upload Resume (PDF, DOC, DOCX)</label>
						<input type="file" name="resume" class="form-control" required accept=".pdf,.doc,.docx">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
					<button type="submit" class="btn wind-btn btn-primary">Submit Application</button>
				</div>
			</form>
		</div>
	</div>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
	$(document).ready(function() {
        var currentJobId, currentJobTitle;

        // 1. When a job card is clicked, fetch details via AJAX
        $('.job-card').on('click', function() {
            currentJobId = $(this).data('id');
            
            $('#modal-loader').show();
            $('#modal-content-area').hide();
            $('.nav-tabs a:first').tab('show');

            $.ajax({
                url: '/job-details/' + currentJobId,
                type: 'GET',
                success: function(job) {
                    currentJobTitle = job.title;
                    $('#jobDetailTitle').text(job.title);
                    $('#jobDetailCompany').text(job.company);
                    $('#jobDetailLocation').text(job.location);
                    $('#jobDetailType').text(job.employment_type);
                    $('#jobDetailAboutCompany').html(job.about_company || 'N/A');
                    $('#jobDetailSummary').html(job.job_summary || 'N/A');
                    $('#jobDetailDuties').html(job.duties_responsibilities || 'N/A');
                    $('#jobDetailEducation').html(job.education_qualifications || 'N/A');
                    $('#jobDetailExperience').html(job.experience_skills || 'N/A');
                    $('#modal-loader').hide();
                    $('#modal-content-area').show();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.error("AJAX Error: " + textStatus, errorThrown);
                    alert('Could not load job details. The URL might be wrong or the server returned an error. Check the console (F12).');
                    $('#jobDetailModal').modal('hide');
                }
            });
        });

        // 2. When "Apply Now" is clicked, open the second modal
        $('.apply-btn').on('click', function() {
            $('#jobDetailModal').modal('hide');
            $('#applyJobId').val(currentJobId);
            $('#applyJobTitle').text(currentJobTitle);
            $('#applyModal').modal('show');
        });
    });
</script><?php /**PATH C:\Users\Administrator\Downloads\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\Dynamic-Website-Using-Laravel-with-Admin-Panel-main\resources\views/index.blade.php ENDPATH**/ ?>